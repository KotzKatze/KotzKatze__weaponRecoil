client_script 'client.lua'
author 'KotzKatze'
fx_version 'adamant'

games { 'rdr3', 'gta5' }